MEIN HAUS / SHTËPIA IME — PREMIUM ICON PACK
Upload all SVG files into the repository folder: /image/
Expected paths in HTML: image/home.svg, image/shopping.svg, etc.

Main modules:
home, shopping, inventory, purchases, finance, appointments, family,
offers, prospectus, stores, bills, budgets, expiry, notifications,
scan, ai, location, transport, tasks, profile, settings, language,
security, help, logout, info, statistics.

Utility:
add, search, edit, delete, back, next, confirm, camera.
